# Numbers > 2025-05-12 4:40pm
https://universe.roboflow.com/datanumbers/numbers-mqugn

Provided by a Roboflow user
License: CC BY 4.0

